Amit Kumar Sahu - 18mis7250
I have shared my complete Project Here

step 1
First I have created 3 packages
-vit.student.dao
-vit.student.services
-vit.student.util

reference:
https://www.youtube.com/watch?v=pBz8cQOrT9Q

step 2
then created 3 class file
-StudentDAO in vit.student.dao      packages
-MainClass  in vit.student.services packages
-DBConnect  in vit.student.util     packages

reference:
https://www.youtube.com/watch?v=4WBCsbbOcHQ
step3
copy the the code i sent in the new file

step 4
adding mongodb jar file to thr program

reference:
https://www.youtube.com/watch?v=sKRZPLrFMa4

step 5
running mongodb in back side

step 6
running the MainClass file




